---
name: mihomo-clash-config-optimization
description: "Optimize Mihomo and Clash proxy configs and fix 403 errors."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, android, macos, windows]
metadata:
  hermes:
    tags: [Mihomo, Clash.Meta, SurfingTile, Proxy, DNS, KeepAlive, QUIC, Fake-IP]
    related_skills: [telegram-proxy, cliproxyapi]
---

# Mihomo / Clash.Meta Configuration & Optimization

When authoring, auditing, or troubleshooting proxy configurations for **Mihomo (Clash.Meta)** and module managers like **SurfingTile**, follow these validated performance directives and architectural principles.

## 1. Top 6 High-Impact Performance & Stability Directives

| Parameter / Directive | Optimal Configuration | Impact & Problem Solved |
| :--- | :--- | :--- |
| **Connection Keep-Alive** | `disable-keep-alive: false`<br>`keep-alive-interval: 60`<br>`keep-alive-idle: 60` | Prevents frequent TCP/TLS handshakes; drastically reduces latency when browsing social feeds (X/Twitter, Web). |
| **Load Balancing Session** | `strategy: sticky-sessions` | Replaces `round-robin` to fix login dropouts, account bans, and repetitive captcha challenges across web services. |
| **Smooth URL Testing** | `tolerance: 200`<br>`lazy: true`<br>`max-failed-times: 3` | Prevents flapping/jitter during minor network fluctuations; saves bandwidth by only probing when group is active. |
| **QUIC GSO Guard** | `quic-go-disable-gso: true` | Prevents driver-level packet dropping and thermal throttling on Android/Linux kernels during YouTube 4K / QUIC streaming. |
| **DNS Cache Algorithm** | `cache-algorithm: arc` | Uses Adaptive Replacement Cache to achieve ~0ms response times for frequently visited domain lookups. |
| **DoH Bootstrap Pre-Resolution** | Explicit IP mapping in `hosts:` | Maps `dns.alidns.com`, `doh.pub`, `dns.google` to direct IPs, resolving recursive DNS deadlocks on cold starts. |

## 2. Robust Regex Patterns for Node Filtering

Avoid single-character ambiguities (e.g. matching `US` inside `PLUS` or `TRUST`). Use emoji flags, case-insensitivity `(?i)`, and word-boundary assertions `(?<![A-Za-z])XX(?![A-Za-z])`:

```yaml
# Hong Kong (香港)
filter: "(?i)(港|🇭🇰|(?<![A-Za-z])HK(?![A-Za-z])|HKG|hkg|hong ?kong)"

# Taiwan (台湾)
filter: "(?i)(台|🇹🇼|新北|彰化|(?<![A-Za-z])TW(?![A-Za-z])|taiwan|taipei|TPE|tpe)"

# Japan (日本)
filter: "(?i)(日|🇯🇵|川日|东京|NRT|nrt|大阪|泉日|埼玉|沪日|深日|[^-]日|(?<![A-Za-z])JP(?![A-Za-z])|japan|JPN)"

# Singapore (狮城/新加坡)
filter: "(?i)(新加坡|坡|狮城|🇸🇬|(?<![A-Za-z])SG(?![A-Za-z])|SIN|sin|singapore|SGP)"

# United States (美国)
filter: "(?i)(美|🇺🇸|(?<![A-Za-z])US(?![A-Za-z])|USA|LAX|lax|SJC|sjc|波特兰|达拉斯|俄勒冈|凤凰城|费利蒙|硅谷|拉斯维加斯|洛杉矶|圣何塞|圣克拉拉|西雅图|芝加哥|united ?states)"

# Netherlands (荷兰)
filter: "(?i)(荷兰|🇳🇱|Netherlands|Nederland|(?<![A-Za-z])NL(?![A-Za-z])|Amsterdam|阿姆斯特丹|AMS|ams)"
```

## 3. Diagnostic Playbook for "HTTP 403 Forbidden" under Modules

When traffic succeeds on official client apps but fails with `HTTP 403` under system proxy/module routing:
1. **DNS Mismatch**: Check `enhanced-mode`. `redir-host` exposes local DNS leaks or mismatch against CDN GeoIP. Switching to `fake-ip` + `sniffer` delegates DNS resolution to remote proxy nodes.
2. **Fingerprint Overrides**: Verify `proxy-providers` override settings. Hardcoded `client-fingerprint: chrome` on non-HTTPS or non-TLS protocols (or certain VMess/VLESS AEAD implementations) triggers server WAF blocks.
3. **NTP Clock Skew**: Ensure `ntp` block is enabled with `ntp.aliyun.com` to prevent TLS handshake / token rejection due to out-of-sync local clocks.
